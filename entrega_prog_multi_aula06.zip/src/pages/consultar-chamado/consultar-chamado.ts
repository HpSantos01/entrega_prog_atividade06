import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ListaProvider } from '../../providers/lista/lista';

/**
 * Generated class for the ConsultarChamadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-consultar-chamado',
  templateUrl: 'consultar-chamado.html',
  providers: [
    ListaProvider
  ]
})
export class ConsultarChamadoPage {
  private lista_chamados = new Array<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams, private listaProvider: ListaProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ConsultarChamadoPage');
  }
 
  ConsultarChamadoPage() {
    this.listaProvider.lista_chamados()
       .subscribe(
         lista => this.lista_chamados = lista);
  }

}
