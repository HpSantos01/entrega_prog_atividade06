import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ListaProvider } from '../../providers/lista/lista';

/**
 * Generated class for the FecharChamadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-fechar-chamado',
  templateUrl: 'fechar-chamado.html',
})
export class FecharChamadoPage {
  private fechar_chamados = new Array<any>();

  constructor(public navCtrl: NavController, public navParams: NavParams, private listaProvider: ListaProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FecharChamadoPage');
  }

  ConsultarChamadoPage() {
    this.listaProvider.lista_chamados()
       .subscribe(
         lista => this.fechar_chamados = lista);
  }
}
