import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { MyApp } from './app.component';

import { AbrirChamadoPageModule } from '../pages/abrir-chamado/abrir-chamado.module';
import { FecharChamadoPageModule } from '../pages/fechar-chamado/fechar-chamado.module';
import { ConsultarChamadoPageModule } from '../pages/consultar-chamado/consultar-chamado.module';
import { TabsPage } from '../pages/tabs/tabs';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ListaProvider } from '../providers/lista/lista';

@NgModule({
  declarations: [
    MyApp,
    TabsPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp), AbrirChamadoPageModule, FecharChamadoPageModule, ConsultarChamadoPageModule,HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TabsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ListaProvider
  ]
})
export class AppModule {}
