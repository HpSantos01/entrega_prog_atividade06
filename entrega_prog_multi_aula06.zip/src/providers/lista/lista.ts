import { Http } from '@angular/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the ListaProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ListaProvider {
  lista_chamados(): any {
    throw new Error("Method not implemented.");
  }
  private Url = 'http://localhost:8080/arqsw_sdesk_a4'

  constructor(public http: Http) {
    console.log('Hello ListaProvider Provider');
  }

  getFilaData() {
    console.log(this.http.get(this.Url + '/rest/chamados/1'));
  }

}
